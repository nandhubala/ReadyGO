package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Driver;
import com.example.demo.services.UserService;

public class UserController {
	@Autowired
	UserService driverService;

	@RequestMapping("/addDriver")
	public void addDriver(@RequestParam("DriverId") int driverId, @RequestParam("DriverName") String driverName,
			@RequestParam("Contact") long contact, @RequestParam("eMail") String eMail,
			@RequestParam("Address") String Address, @RequestParam("city") String city,
			@RequestParam("Password") String password, @RequestParam("License") String license,
			@RequestParam("Experiance") int experiance) {
			Driver driver=new Driver();
			driver.setDriverId(driverId);
			driver.setDriverName(driverName);
			driver.setContact(contact);
			driver.seteMail(eMail);
			driver.setAddress(Address);
			driver.setCity(city);
			driver.setPassword(password);
			driver.setLicense(license);
			driver.setExperiance(experiance);
			driverService.addDriver(driver);
	}

}
