package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.DAO.ReadyGoDAO;
import com.example.demo.model.Driver;

public class UserService {
	@Autowired
	ReadyGoDAO dao;
	public void addDriver(Driver driver) {
		// TODO Auto-generated method stub
		dao.addDriver(driver);
		
	}

}
