package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.example.demo.model.Driver;



public class ReadyGoDAO {
	
	
		public Connection connectTODB() {
			Connection connection = null;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
				return connection;
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
				return null;
			}
		}
		public void addDriver(Driver driver) {
			try {
				Connection con = connectTODB();
				PreparedStatement stmt = con.prepareStatement("insert into Books values(?,?,?,?,?,?,?,?,?)");
				stmt.setInt(1, driver.getDriverId());
				stmt.setString(2, driver.getDriverName());
				stmt.setLong(3, driver.getContact());
				stmt.setString(4, driver.geteMail());
				stmt.setString(5, driver.getAddress());
				stmt.setString(6, driver.getCity());
				stmt.setString(7, driver.getPassword());
				stmt.setString(8, driver.getLicense());
				stmt.setInt(9, driver.getExperiance());
				// Step 4: Execute SQL Query
				int affectedRows = stmt.executeUpdate();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


}
}

	
